package com.GlobalBakingTransactionMicroservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ACCOUNT")
public class Account
{
	@Id
	
	 @Column(name="USER_NAME")
		private String userName;
	
	//Account Number
	@Column(name="ACCOUNT_NO")
	private long accountNo;
	
   
	
	@Column(name="ACCOUNT_BALANCE")
	private double accountBalance;
	

	public Account()
	{
		
	}
	
	public Account(long accountNo,String userName,double accountBalance)
	{
		this.accountBalance=accountBalance;
		this.userName=userName;
		this.accountBalance=accountBalance;
		
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "accountNo=" + accountNo + "\nuserName=" + userName + "\naccountBalance=" + accountBalance
				+ "\n";
	}
	
}
