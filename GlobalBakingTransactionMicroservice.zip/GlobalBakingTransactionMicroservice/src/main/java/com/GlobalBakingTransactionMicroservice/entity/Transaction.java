package com.GlobalBakingTransactionMicroservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TRANSACTION")
public class Transaction 
{
	@Id
	//Transaction Id
   @Column(name="TRANSACTION_ID")
	private String transactionId;
	
	@Column(name="FROM_ACCOUNT")
	private String fromAccount;
	
	@Column(name="To_ACCOUNT")
	private String toAccount;
	
	@Column(name="AMOUNT")
	private double amount;


public Transaction()
{
	
}

public Transaction(String transactionId,String fromAccount,String toAccount,double amount)
{
	this.transactionId=transactionId;
	this.fromAccount=fromAccount;
	this.toAccount=toAccount;
	this.amount=amount;
	
}

public String getTransactionId() {
	return transactionId;
}

public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
}


public String getFromAccount() {
	return fromAccount;
}

public void setFromAccount(String fromAccount) {
	this.fromAccount = fromAccount;
}

public String getToAccount() {
	return toAccount;
}

public void setToAccount(String toAccount) {
	this.toAccount = toAccount;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

@Override
public String toString() {
	return "transactionId=" + transactionId + "\nfromAccount=" + fromAccount + "\ntoAccount=" + toAccount
			+ "\namount=" + amount + "\n";
}

}

