package com.GlobalBankingTransactionMicroservice.controller;

import java.util.List;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.GlobalBakingTransactionMicroservice.entity.Account;
import com.GlobalBakingTransactionMicroservice.repository.AccountRepository;
import com.GlobalBakingTransactionMicroservice.repository.TransactionRepository;



@RestController
@RequestMapping("/api")
public class TransactionController
{
	@Autowired
	TransactionRepository transactionRepository;
	//UserRepository userRepository;
	AccountRepository accountRepository;
//	AccountRepository accountRepository;
	
	
	@GetMapping("/transaction")
	protected List<Transaction> getAllTransactions()
	{
		List<Transaction> transactions=transactionRepository.findAll();
		return transactions;
	}
	
	
	@PutMapping("/transferFrom/{id}")
	private Transaction transferamt(@PathVariable(value = "id") String transactionId,
			@RequestBody Transaction transferFor)
	{
		
	    Transaction transfer=transactionRepository.findById(transactionId).get();
	    transfer.setTransactionId(transferFor.getTransactionId());
	    transfer.setFromAccount(transferFor.getFromAccount());
	    transfer.setToAccount(transferFor.getToAccount());
	    transfer.setAmount(transferFor.getAmount());
	    Transaction updateamt=transactionRepository.save(transfer);
	    return updateamt;
	}
	
	@PostMapping("/transaction")
	private Transaction transfer(@RequestBody Transaction  transferFromBrowser)
	{
		Transaction transaction=null;
		String SenderName=transferFromBrowser.getFromAccount();
		String recevierName=transferFromBrowser.getToAccount();
		double amount=transferFromBrowser.getAmount();
		
		User user1=userRepository.getById(SenderName);
		User user2=userRepository.getById(recevierName);
		Account senderAccount=accountRepository.getById(SenderName);
		double senderamt=senderAccount.getAccountBalance();
		Account recevierAccount=accountRepository.getById(recevierName);
		 double recevieramt=recevierAccount.getAccountBalance();
		
		if(amount <=senderamt && amount>0)
		{
			double currentbal=senderamt-amount;
		    user1.setTotalBalance(currentbal);
		    userRepository.save(user1);
		    senderAccount.setAccountBalance(currentbal);
		
		    double currentbal1=recevieramt+amount;
		    user2.setTotalBalance(currentbal1);
		    userRepository.save(user2);
		    recevierAccount.setAccountBalance(currentbal1);
		
		List<Transaction> list=transactionRepository.findAll();
		//int count=list.size();
		//String TransactionId = null;
		transaction=new Transaction(transferFromBrowser.getTransactionId(),SenderName,recevierName,amount);
		transactionRepository.save(transaction);
		}
		return transaction;
		
		}
 
	}
