//package com.fmcgglobal;
//
//import java.util.Scanner;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//import com.fmcgglobal.entity.Product;
//import com.fmcgglobal.repository.ProductRepository;
//
//@SpringBootApplication
//
//public class FmcgglobalDesktopSpringCoreApp implements CommandLineRunner
//{
//	Scanner scanner =null;
//	
//	//Spring Framwork Create the Instance of Product Repository
//	//And Injects it Dependency Injection(Di)
//	
//	@Autowired
//	ProductRepository productRepository;
//	
//	public static void main(String[] args) 
//	{
//		SpringApplication.run(FmcgglobalWebSpringApp.class, args);
//		
//	}
//	public FmcgglobalDesktopSpringCoreApp()
//	{
//		scanner=new Scanner(System.in);
//	}
//
//	private void showMenu()
//	{
//		System.out.println("...........Welcome to Fmcggloobal......");
//        System.out.println("========================================");
//        while_label:while(true)
//        {
//        	System.out.println("\n1.Find the Product");
//        	System.out.println("\n2.Insert the Product");
//        	System.out.println("\n3.Update the Product");
//        	System.out.println("\n4.Delete the Product");
//        	System.out.println("0.Exit");
//        	System.out.println("Enter the Choice");
//        	int choice=Integer.parseInt(scanner.nextLine());
//        	System.out.println();
//        	
//        	switch(choice)
//        	{
//        	case 1:
//        	{
//        		searchProduct();
//        		break;
//        	}
//        	case 2:
//        	{
//        		insertProduct();
//        		break;
//        	}
//        	case 3:
//        	{
//        		updateProduct();
//        		break;
//        	}
//        	case 4:
//        	{
//        		deleteProduct();
//        		break;
//        	}
//        	case 0:
//        	{
//        		break while_label;
//        	}
//        	default:
//        	{
//        		System.out.println("Enter the Valid Option");
//        	}
//        	System.out.println("Thank you for Visting..!!!!!!!!");
//        	System.out.println("===============================");	
//        }
//        }
//	}
//        private void searchProduct()
//        {
//        	Product product =productRepository.findById("HP01").get();
//        	if(product!=null)
//        	{
//        		System.out.println(product);
//        	}
//        	else
//        	{
//        		System.out.println("Product Not Found!!!!.....");
//        		
//        	}
//        }
//        
//        private void insertProduct()
//        {
//        	// Accept Product from User
//        	Product product=new Product("PH06","Fruits",50,90);
//        	productRepository.save(product);
//        	System.out.println("Product Inserted Sucessfully....");
//     
//        }
//        
//        private void updateProduct()
//        {
//        	Product product=productRepository.findById("HP05").get();
//        	product.setProductName("Orange");
//        	product.setPrice(450);
//        	product.setQuantity(90);
//        	productRepository.save(product);
//        	System.out.println("Product Update Sucessfully.....");
//        }
//        private void deleteProduct()
//        {
//        	System.out.println("Enter the ProductId to delete...");
//        	String productId=scanner.nextLine();
//        	Product product=productRepository.findById(productId).get();
//        	productRepository.delete(product);	
//        }
//	@Override
//	public void run(String... args) throws Exception 
//	{
//	 this.showMenu();
//		
//	}
//
//	
//}
