package com.fmcgglobal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCT")
public class Product
{
	@Id
	
	//productId // PRODUCTID
	@Column(name="PRODUCT_ID")
	private String productId;
	
	//productName //productname
	@Column(name="PRODUCT_NAME")
	private String productName;
	
	//price // PRICE
	@Column(name="PRICE")
	private int price;
	
	//quantity //QUANTITY
	@Column(name="QUANTITY")
	private int quantity;
	
	public Product()
	{
		
	}
	public Product(String productId,String productName,int price,int quantity )
	{
		this.productId=productId;
		this.productName=productName;
		this.price=price;
		this.quantity=quantity;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "productId=" + productId + "\nproductName=" + productName + "\nprice=" + price + "\nquantity="
				+ quantity + "\n";
	}
	

}
