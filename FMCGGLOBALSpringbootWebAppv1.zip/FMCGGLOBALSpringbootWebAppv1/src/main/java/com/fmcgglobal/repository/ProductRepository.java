package com.fmcgglobal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fmcgglobal.entity.Product;

@Repository

public interface ProductRepository extends JpaRepository<Product, String>
{
//	/**
//  * Finds a product by using the productName as search criteria.
//  * @param productNameParam
//  * @return  A list of products whose name is an exact match with the given productName.
//  * If no products are found, this method returns an empty list.
//  */
	
	
	@Query ("select product from Product product where product.productName=:productNameParam")
	public List<Product> findByProductName(@Param("productNameParam")String productName);

}

















