package com.fmcgglobal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FmcgglobalWebSpringApp {

	public static void main(String[] args) 
	{
		SpringApplication.run(FmcgglobalWebSpringApp.class, args);
		System.out.println("Welcome to Springboot......");
	}

}
