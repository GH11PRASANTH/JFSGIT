package com.fmcgglobal;

import java.util.Scanner;

import org.springframework.web.client.RestTemplate;

import com.fmcgglobal.entity.Product;
import com.fmcgglobal.entity.ProductResponse;

public class FmcgglobalDesktopSpringRESTApp
{
	static Scanner scanner=null;
	
	public FmcgglobalDesktopSpringRESTApp()
	{
		scanner=new Scanner(System.in);
	}
	final static RestTemplate restTemplate;
    final static String restAPIURLString="http://localhost:9091/FMCGGLOBALHIBERNATEAppV1/api/";

	static
	{
		restTemplate =new RestTemplate();
	}
	
	public static void main(String[] args) 
	{
		System.out.println("FMCGGLOBALDesktopSpringRESTApp");
	    getAllProducts();
	    saveProduct();
	    getAllProducts();
	    updateProduct();
	    getAllProducts();
	    deleteProduct();
	    getAllProducts();
	}
	private static void getAllProducts()
	{
		ProductResponse productResponse=restTemplate.getForObject(restAPIURLString + "productResponse",
				ProductResponse.class);
		productResponse.getProduct().forEach(System.out::println);
	}
	private static void saveProduct()
	{
//		
//		System.out.println("Enter the ProductId..");
//		String proId=scanner.nextLine();
//		System.out.println("Enter the ProductName....");
//		String proName=scanner.nextLine();
//		System.out.println("Enter the Product Price...");
//		int price=Integer.parseInt(scanner.nextLine());
//		System.out.println("Enter the Product Quantity...");
//		int quantity=Integer.parseInt(scanner.nextLine());
		Product product=new Product("AP05","car",5330,78);
		Product createProduct=restTemplate.postForObject(restAPIURLString+"product", product, Product.class);
	//	scanner.close();
		System.out.println("Your Product saved sucessfully....."+createProduct);
		
	}
	private static void updateProduct()
	{
		Product product=new Product("AP01","Orange",1230,2);
		restTemplate.put(restAPIURLString +"product", product.getProductId(), product);
		System.out.println("Update the Product........");
	}
	
	private static void deleteProduct()
	{
		String productId="AP01";
		restTemplate.delete(restAPIURLString+"product" +productId);
	}
}
